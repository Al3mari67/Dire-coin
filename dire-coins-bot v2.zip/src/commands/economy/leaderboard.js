'use strict';

// ╔══════════════════════════════════════════════════════════╗
// ║        Dire Coin's Bot - Leaderboard Command               ║
// ║                  !leaderboard / !lb                        ║
// ╚══════════════════════════════════════════════════════════╝

const db = require('../../database/DatabaseManager');
const Embeds = require('../../utils/EmbedBuilder');

module.exports = {
  name: 'leaderboard',
  aliases: ['lb', 'top', 'rich'],
  description: "Show the top 10 richest members in the server.",
  usage: '!leaderboard',
  category: 'economy',

  /**
   * @param {import('discord.js').Message} message
   */
  async execute(message) {
    const entries = db.getLeaderboard(message.guild.id, 10);

    const embed = Embeds.leaderboard({
      guildName: message.guild.name,
      entries,
    });

    await message.reply({ embeds: [embed] });
  },
};
