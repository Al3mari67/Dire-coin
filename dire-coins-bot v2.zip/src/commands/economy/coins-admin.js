'use strict';

// ╔══════════════════════════════════════════════════════════╗
// ║      Dire Coin's Bot - Admin Coin Management Command       ║
// ║        !addcoins @user <amount>  (Administrator only)      ║
// ║        !removecoins @user <amount>  (alias: -coins)        ║
// ╚══════════════════════════════════════════════════════════╝

const { PermissionsBitField } = require('discord.js');
const config = require('../../config/config');
const db = require('../../database/DatabaseManager');
const Embeds = require('../../utils/EmbedBuilder');

module.exports = {
  name: 'addcoins',
  aliases: ['removecoins', 'givecoins', 'takecoins'],
  description: "Add or remove a member's Dire Coins (Administrator only).",
  usage: '!addcoins @user <amount>  |  !removecoins @user <amount>',
  category: 'economy',

  /**
   * @param {import('discord.js').Message} message
   * @param {string[]} args
   */
  async execute(message, args) {
    const { member, mentions, guild, content } = message;

    // ── Permission Check ───────────────────────────────────
    if (!member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply({
        embeds: [Embeds.error('Permission Denied', 'Only server administrators can use this command.')],
      });
    }

    // Figure out whether this invocation is add or remove
    const invokedAs = content
      .slice(config.prefix.length)
      .trim()
      .split(/\s+/)[0]
      .toLowerCase();
    const isRemove = ['removecoins', 'takecoins'].includes(invokedAs);

    const target = mentions.members?.first();
    const rawAmount = args[1];
    const amount = parseInt(rawAmount, 10);

    if (!target || !rawAmount || !Number.isFinite(amount) || amount <= 0) {
      return message.reply({
        embeds: [
          Embeds.error(
            'Invalid Usage',
            `Correct usage: \`${config.prefix}${invokedAs} @user <amount>\`\nExample: \`${config.prefix}${invokedAs} @John 500\``
          ),
        ],
      });
    }

    const delta = isRemove ? -amount : amount;
    const newBalance = db.addBalance(target.id, guild.id, target.user.tag, delta);

    return message.reply({
      embeds: [
        Embeds.warning(
          isRemove ? 'Coins Removed' : 'Coins Added',
          `${isRemove ? 'Removed' : 'Added'} ${Embeds.coins(amount)} ${isRemove ? 'from' : 'to'} <@${target.id}>'s wallet.\nNew balance: ${Embeds.coins(newBalance)}`
        ),
      ],
    });
  },
};
