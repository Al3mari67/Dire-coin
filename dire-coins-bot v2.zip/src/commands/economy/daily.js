'use strict';

// ╔══════════════════════════════════════════════════════════╗
// ║          Dire Coin's Bot - Daily Reward Command            ║
// ║                       !daily                                ║
// ╚══════════════════════════════════════════════════════════╝

const config = require('../../config/config');
const db = require('../../database/DatabaseManager');
const Embeds = require('../../utils/EmbedBuilder');

module.exports = {
  name: 'daily',
  aliases: ['claim'],
  description: 'Claim your free daily Dire Coins.',
  usage: '!daily',
  category: 'economy',

  /**
   * @param {import('discord.js').Message} message
   */
  async execute(message) {
    const { author, guild } = message;
    const cooldownSeconds = config.daily.cooldownHours * 3600;

    const result = db.claimDaily(
      author.id,
      guild.id,
      author.tag,
      config.daily.amount,
      cooldownSeconds
    );

    if (!result.success) {
      const hours = Math.floor(result.remainingSeconds / 3600);
      const minutes = Math.ceil((result.remainingSeconds % 3600) / 60);
      return message.reply({
        embeds: [
          Embeds.warning(
            'Already Claimed',
            `You've already claimed your daily reward!\nCome back in **${hours}h ${minutes}m**.`
          ),
        ],
      });
    }

    const embed = Embeds.dailySuccess({
      user: { id: author.id },
      amount: result.amount,
      balance: result.balance,
    });

    await message.reply({ embeds: [embed] });
  },
};
