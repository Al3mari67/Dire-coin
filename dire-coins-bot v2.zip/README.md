# Dire Coin's Economy Bot 🪙

A professional Discord economy bot with a complete command system built with Discord.js and better-sqlite3.

## ⚠️ SECURITY NOTICE

A previous version of your bot token was exposed. **You MUST regenerate it before deploying anywhere**:

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Select your application → **Bot**
3. Click **Reset Token**
4. Copy the new token into your `.env` file's `BOT_TOKEN` value (never commit `.env` to git — it's already in `.gitignore`)

## 📁 Project Structure

```
dire-coins-bot/
├── src/
│   ├── index.js              # Entry point
│   ├── config/
│   │   └── config.js         # Configuration file
│   ├── commands/
│   │   ├── economy/
│   │   │   ├── balance.js    # !balance command
│   │   │   └── pay.js        # !pay command
│   │   └── info/
│   │       └── help.js       # !help command
│   ├── events/
│   │   ├── ready.js          # Bot ready event
│   │   ├── messageCreate.js  # Message handler
│   │   └── guildMemberAdd.js # New member event
│   ├── database/
│   │   └── DatabaseManager.js # SQLite database
│   └── utils/
│       ├── CommandHandler.js  # Command loader
│       ├── EmbedBuilder.js    # Embed templates
│       ├── CooldownManager.js # Cooldown system
│       └── Logger.js          # Logging utility
├── .env                       # Environment variables
├── package.json               # Dependencies
└── README.md                  # This file
```

## 🚀 Installation & Setup

### 1. Prerequisites
- Node.js 18+ 
- npm or yarn

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment
Edit `.env` file with your bot settings:
```
BOT_TOKEN=your_bot_token_here
PREFIX=!
LOG_CHANNEL_ID=your_channel_id
STARTING_BALANCE=500
TRANSFER_COOLDOWN=10
MAX_TRANSFER=1000000
MIN_TRANSFER=1
```

### 4. Run the Bot
**Development mode** (with auto-reload):
```bash
npm run dev
```

**Production mode**:
```bash
npm start
```

## 💰 Available Commands

### Economy Commands
- `!balance` / `!bal` - View your wallet
- `!balance @user` - View someone's wallet
- `!pay @user <amount>` - Transfer coins
- `!s @user <amount>` - Shortcut for pay
- `!daily` - Claim your free daily coins
- `!leaderboard` / `!lb` - Top 10 richest members

### Admin Commands (require Administrator permission)
- `!addcoins @user <amount>` - Give coins to a member
- `!removecoins @user <amount>` - Take coins from a member

### Info Commands
- `!help` - Show command guide

### Amount Shortcuts
- `1k` = 1,000
- `1m` = 1,000,000
- `500` = exact amount

## 📊 Database

Uses **better-sqlite3** for data storage:
- User balances and transaction history
- Automatic schema creation on first run
- Data stored in `data/economy.db`

## 🔧 Configuration

Edit `src/config/config.js` or `.env`:

```javascript
// Economy settings
startingBalance: 500        // New member balance
minTransfer: 1              // Minimum amount
maxTransfer: 1_000_000      // Maximum amount
transferCooldown: 10        // Seconds between transfers
```

## 🚀 Upcoming Features

- Shop/Store
- Gambling mini-game

## ☁️ Hosting (24/7)

This bot needs a host that keeps a Node.js process **running continuously** and, since it uses `better-sqlite3`, ideally offers **persistent disk storage** so your economy data survives restarts/redeploys.

### Option A — Railway.app (easiest, ~$5/month after free trial credit)
1. Push this project to a GitHub repo (make sure `.env` stays out of git — it's in `.gitignore`).
2. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub repo**.
3. In the service **Variables** tab, add: `BOT_TOKEN`, `PREFIX`, `LOG_CHANNEL_ID`, `STARTING_BALANCE`, `TRANSFER_COOLDOWN`, `MAX_TRANSFER`, `MIN_TRANSFER`, `DAILY_AMOUNT`, `DAILY_COOLDOWN_HOURS`, and `DATA_DIR=/data`.
4. Go to the **Volumes** tab → create a volume, mount it at `/data`. This makes your SQLite database persist across redeploys.
5. Deploy. Railway auto-runs `npm start`.

### Option B — Render.com (Background Worker, ~$7/month for a persistent disk)
1. Push to GitHub, then on [render.com](https://render.com) create a **Background Worker** (not "Web Service" — this bot doesn't listen on a port).
2. Build command: `npm install`. Start command: `npm start`.
3. Add the same environment variables as above, with `DATA_DIR=/data`.
4. Add a **Disk**, mount path `/data`, so the database persists.

### Option C — A cheap VPS (most control, ~$4-6/month — e.g. Contabo, Hetzner, DigitalOcean)
1. Get a small Ubuntu VPS, SSH into it, install Node.js 18+ and git.
2. `git clone` your repo (or upload the folder via `scp`).
3. `cd dire-coins-bot && npm install`, then create `.env` with your real values (leave `DATA_DIR` unset — the local `data/` folder is already persistent on a VPS).
4. Install PM2 to keep it running and auto-restart on crash/reboot:
   ```bash
   npm install -g pm2
   pm2 start src/index.js --name dire-coins-bot
   pm2 save
   pm2 startup   # follow the printed command to enable on reboot
   ```
5. `pm2 logs dire-coins-bot` to check it's online.

**Avoid**: free/serverless platforms with no persistent disk (e.g. plain Heroku free dynos, Vercel, Netlify) — the SQLite file gets wiped on every restart/redeploy and you'll lose all balances.

## 🤝 Support

If you encounter issues:
1. Check that all environment variables are set correctly
2. Ensure node_modules are installed (`npm install`)
3. Check console logs for specific error messages
4. Verify database permissions in `data/` folder

## 📄 License

MIT License - See LICENSE file for details

---

**Bot created with ❤️ using Discord.js 14**
